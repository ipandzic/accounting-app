    <template>
        <div class="projects">
        <h1>Projects</h1>
        <form v-on:submit="addProject">
          <input type="text" v-model="newProject.name" placeholder="Enter Name">
          <br />Is the project internal?<input type="checkbox" class=toggle v-model="newProject.internal">
          <br />

          <input type="radio" id="one" value="true" v-model="newProject.active">
          <label for="one">Yes</label>
          <br />
          <input type="radio" id="two" value="false" v-model="newProject.active">
          <label for="two">No</label>   
          <br />

          <input type="submit" value="Submit">
        </form>
        <ul>
          <li v-for="project in projects">
            {{project.name}}: <br />Internal: {{project.internal}}
            <br />Active: {{project.active}} <button v-on:click="deleteProject(project)">X</button>
          </li>
        </ul>

        </div>
    </template>

    <script>
      export default {
        name: 'projects',
        data () {
          return {
            newProject: {},
            projects: [
              {
                name: 'First project for Pliva',
                internal: false,
                active: true
              },
              {
                name: 'Second project for Pliva',
                internal: false,
                active: true
              }
            ]
          }
        },
        methods: {
          addProject: function (e) {
            this.projects.push({
              name: this.newProject.name,
              internal: this.newProject.internal,
              active: this.newProject.active
            })
            e.preventDefault()
          },
          deleteProject: function (project) {
            this.projects.splice(this.projects.indexOf(project), 1)
          }
        }
      }
    </script>

    <style scoped>
        
    </style>
